﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace gasolinera_json
{
    public class Bomba
    {
        public int Contador { get; set; }
        public int Prepago { get; set; }
        public int TanqueLleno {  get; set; }

    
        

    }
}
